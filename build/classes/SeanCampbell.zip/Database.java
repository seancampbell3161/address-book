
public class Database {
    
    //create variables for database connection url, username, and password
    public static final String DATABASE_URL="jdbc:derby://localhost:1527/addressbook";
    public static final String USERNAME="uta";
    public static final String PASSWORD="12345";
    
}
